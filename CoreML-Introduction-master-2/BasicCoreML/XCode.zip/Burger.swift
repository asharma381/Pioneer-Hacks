//
//  Burger.swift
//  BasicCoreML
//
//  Created by Aditya Sharma on 3/17/18.

import UIKit

class Burger: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
